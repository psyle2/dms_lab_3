package com.COMP2013;

public interface Employable {

    public void setEmployeeID(int number);

    public int getEmployeeID();

    public void setEmployeeName(String name);

    public String getEmployeeName();

    public int getSalary();

    public void setSalary(int salary);

    public int calculateChristmasBonus();
}
