package com.COMP2013;

public interface Maintainable {
    public void maintain();
}
